﻿
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        Console.WriteLine("¡Bienvenido a la Carrera de Coches Asíncrona!");
        Console.WriteLine("============================================\n");

        var cts = new CancellationTokenSource();
        var token = cts.Token;

        try
        {
            // Crear los coches participantes
            var coche1 = CorrerCoche("🚗 Rojo", 100, token);
            var coche2 = CorrerCoche("🚙 Azul", 100, token);
            var coche3 = CorrerCoche("🏎️ Verde", 100, token);

            // Crear una tarea para monitorear eventos aleatorios
            var eventosAleatorios = Task.Factory.StartNew(async () =>
            {
                while (!token.IsCancellationRequested)
                {
                    await Task.Delay(2000);
                    Console.WriteLine("\n⚡ ¡Evento aleatorio ocurriendo!");
                }
            }, token, TaskCreationOptions.AttachedToParent, TaskScheduler.Default);

            // Esperar a que cualquier coche termine
            var ganador = await Task.WhenAny(coche1, coche2, coche3);
            
            // Cancelar las demás tareas cuando hay un ganador
            cts.Cancel();

            Console.WriteLine($"\n🏆 ¡{await ganador} ha ganado la carrera!");
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("\nLa carrera ha sido cancelada.");
        }
        finally
        {
            cts.Dispose();
        }
    }

    static async Task<string> CorrerCoche(string nombre, int distancia, CancellationToken token)
    {
        int progreso = 0;
        var random = new Random();

        // Tarea principal de la carrera
        var carrera = Task.Run(async () =>
        {
            while (progreso < distancia && !token.IsCancellationRequested)
            {
                await Task.Delay(100);
                progreso += random.Next(1, 4);
                MostrarProgreso(nombre, progreso, distancia);
            }
            return nombre;
        }, token);

        // Continuar con efectos aleatorios
        var efectos = carrera.ContinueWith(async (antTask) =>
        {
            while (!token.IsCancellationRequested)
            {
                await Task.Delay(random.Next(3000, 5000));
                if (random.Next(2) == 0)
                {
                    progreso += 5;
                    Console.WriteLine($"\n🚀 ¡Turbo activado para {nombre}!");
                }
                else
                {
                    progreso -= 3;
                    Console.WriteLine($"\n🔧 ¡Problema mecánico para {nombre}!");
                }
            }
        }, token, TaskContinuationOptions.OnlyOnRanToCompletion, TaskScheduler.Default);

        return await carrera;
    }

    static void MostrarProgreso(string nombre, int progreso, int total)
    {
        int porcentaje = (int)((float)progreso / total * 100);
        porcentaje = Math.Min(100, Math.Max(0, porcentaje));
        
        Console.SetCursorPosition(0, Console.CursorTop);
        Console.Write($"{nombre}: [");
        int completado = (int)(porcentaje / 2);
        Console.Write(new string('=', completado));
        Console.Write(new string(' ', 50 - completado));
        Console.Write($"] {porcentaje}%\r");
    }
}

/* Esto consiste en un juego de carreras donde compiten varios coches de diferentes colores, este utiliza todos los
constructores tratados en clase hasta el momento, además de hacerlo visualmente representativo con la ayuda de la IA.
El juego es aleatorio, puede ganar cualquiera de los colores.*/